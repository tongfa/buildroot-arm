// HC2.h

#ifndef __HC2_H
#define __HC2_H

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC2

#include "HCMF.h"
#include "HCMFMain.h"

#endif

