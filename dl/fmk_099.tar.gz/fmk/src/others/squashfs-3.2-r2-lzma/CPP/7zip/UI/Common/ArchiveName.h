// ArchiveName.h

#ifndef __ARCHIVENAME_H
#define __ARCHIVENAME_H

#include "Common/MyString.h"

UString CreateArchiveName(const UString &srcName, bool fromPrev, bool keepName);

#endif
